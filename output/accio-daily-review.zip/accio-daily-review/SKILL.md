---
name: accio-daily-review
description: Alibaba.com International Station daily review skill for yesterday-to-today operational review, change summary, priority products, and today action recommendations. Use when the user wants the daily经营复盘与今日执行建议 task or a structured daily shop review.
---

# Accio Daily Review

Use this skill only for the daily review workflow. It reviews yesterday's store and industry data and turns it into today's execution suggestions. Do not use it for weekly review or keyword scan. Use America/Los_Angeles as the date boundary, and interpret "today" and "yesterday" in America/Los_Angeles time. Write the task logic in English, but output the final answer in Chinese only.

## Scope

- Review the previous day only
- Focus on yesterday's major changes, new opportunities, and new problems
- Prioritize products that need action today
- Give title, selling point, and keyword optimization suggestions per product
- End with the top 3 actions for today
- Do not handle weekly review or keyword scan content in this skill

## Operating rules

- Retrieve the actual store and industry data first
- If retrieval fails, stop and report `data not retrieved`
- Use America/Los_Angeles as the date boundary for the requested day
- Do not use weekly boundaries or weekly comparisons
- Treat any "today" and "yesterday" references as America/Los_Angeles dates, not China time
- Keep the output structured and directly actionable
- Do not invent metrics or product results
- If a conclusion is weak, label it as a hypothesis

## Recommended output

1. 昨日概览
2. 新机会与新问题
3. 优先产品
4. 产品优化建议
5. 今日前三行动
