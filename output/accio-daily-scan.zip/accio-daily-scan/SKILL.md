---
name: accio-daily-scan
description: Alibaba.com International Station daily keyword and product scan skill for uncovered keywords, rising demand, priority products, and quick optimization actions. Use when the user wants the daily国际站选词与待优化扫描 task.
---

# Accio Daily Scan

Use this skill only for the daily keyword and product scan workflow. It finds keywords and products worth optimizing for the previous natural day. Do not use it for daily review or weekly review. Use America/Los_Angeles as the date boundary, and interpret the scan day as yesterday in America/Los_Angeles time. Write the task logic in English, but output the final answer in Chinese only.

## Scope

- Find uncovered keywords
- Find keywords with rising industry demand
- Find buyer-preferred keywords worth using in titles
- Find products with high supply-demand ratio and low competition
- Return the 3 most actionable moves for yesterday
- Do not handle daily review or weekly review content in this skill

## Operating rules

- Retrieve the actual store and industry data first
- If retrieval fails, stop and report `data not retrieved`
- Use America/Los_Angeles as the date boundary for the previous natural day
- Treat "yesterday" as America/Los_Angeles time, not China time
- Focus on what can be acted on for yesterday's data
- Keep the output concise, structured, and reusable
- Do not turn it into a weekly or monthly review
- Do not invent demand or competition data

## Recommended output

1. 关键词缺口
2. 上升需求关键词
3. 优先产品
4. 可执行的标题/卖点/关键词建议
5. 今日前三行动
