# Accio 周报分享站

这个仓库里已经准备好了一个可直接发布到 GitHub Pages 的静态站点，用来给客户查看周报，不需要让客户打开 `.md`。

## 发布目录

- `site/index.html`：站点首页，等同分享页入口
- `site/report-share.html`：固定分享页
- `site/report-miniapp.html`：手机查看页
- `site/weekly_report/latest.html`：最新周报
- `site/share-qr.png`：分享二维码

## 生成站点

一个命令就够：

```bash
python3 build_github_pages_site.py
```

## 发布到 GitHub Pages

仓库已经带了 GitHub Actions 自动发布流程：

1. 把仓库推到 GitHub 的 `main` 分支。
2. 在仓库设置里打开 Pages，并把 Source 设为 `GitHub Actions`。
3. 以后只要更新 `output/weekly_report/*.md` 或重新生成站点，推送后会自动发布。
4. 发布完成后，客户直接访问生成的 `github.io` 地址即可。

## 说明

- 这个站点不依赖自定义域名，先用免费的 `github.io` 地址就够。
- 如果以后你要换域名，可以再绑定自定义域名。
- `site/report-share.html` 和 `site/index.html` 都会指向最新周报页。
- `site/` 是最终发布产物，GitHub Actions 会自动从这里部署。
- `build_github_pages_site.py` 会自动同步周报、生成二维码，并产出可发布目录。
