#!/usr/bin/env python3
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

from md_to_html import build_html, render_markdown


ROOT = Path(__file__).resolve().parent
SITE = ROOT / "site"
WEEKLY_DIR = ROOT / "output" / "weekly_report"


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def build_index() -> str:
    return """<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
  <title>周报分享页</title>
  <style>
    :root{
      --bg:#f3efe6;
      --panel:#fffaf2;
      --text:#1f1a17;
      --muted:#72675c;
      --line:#e1d5c4;
      --accent:#0f766e;
      --shadow:0 20px 60px rgba(31,26,23,.10);
      --radius:24px;
    }
    *{box-sizing:border-box}
    html,body{height:100%}
    body{
      margin:0;
      font-family:system-ui,-apple-system,BlinkMacSystemFont,"PingFang SC","Hiragino Sans GB","Microsoft YaHei",sans-serif;
      color:var(--text);
      background:
        radial-gradient(circle at top, rgba(15,118,110,.12), transparent 30%),
        linear-gradient(180deg,#faf6ee 0%, #efe6d7 100%);
    }
    .phone{
      max-width:480px;
      min-height:100%;
      margin:0 auto;
      padding:14px 14px 24px;
    }
    .hero,.card{
      background:rgba(255,250,242,.92);
      border:1px solid rgba(225,213,196,.95);
      border-radius:28px;
      box-shadow:var(--shadow);
    }
    .hero{padding:18px 16px 16px;}
    .summary{
      display:grid;
      grid-template-columns:repeat(3, 1fr);
      gap:10px;
      margin-top:14px;
    }
    .summary .item{
      background:rgba(255,255,255,.72);
      border:1px solid rgba(225,213,196,.95);
      border-radius:18px;
      padding:11px 12px;
      min-height:72px;
    }
    .summary .label{
      display:block;
      color:var(--muted);
      font-size:12px;
      margin-bottom:6px;
    }
    .summary .value{
      display:block;
      font-size:13px;
      line-height:1.45;
      font-weight:700;
    }
    .stack{
      margin-top:14px;
      padding:14px;
      border-radius:22px;
      background:linear-gradient(180deg, rgba(15,118,110,.10), rgba(255,255,255,.68));
      border:1px solid rgba(225,213,196,.95);
    }
    .stack-head{
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:10px;
      margin-bottom:12px;
    }
    .stack-head h2{
      margin:0;
      font-size:16px;
      letter-spacing:-.02em;
    }
    .stack-head span{
      color:var(--muted);
      font-size:12px;
      white-space:nowrap;
    }
    .checklist{
      display:grid;
      gap:8px;
    }
    .check{
      display:flex;
      gap:10px;
      align-items:flex-start;
      padding:10px 12px;
      border-radius:16px;
      background:rgba(255,255,255,.72);
      border:1px solid rgba(225,213,196,.95);
      font-size:13px;
      line-height:1.5;
    }
    .check strong{display:block}
    .mark{
      flex:0 0 auto;
      width:22px;
      height:22px;
      border-radius:999px;
      display:grid;
      place-items:center;
      background:rgba(15,118,110,.12);
      color:var(--accent);
      font-weight:900;
      font-size:13px;
      margin-top:1px;
    }
    .eyebrow{
      display:inline-flex;
      padding:6px 11px;
      border-radius:999px;
      background:rgba(15,118,110,.10);
      color:var(--accent);
      font-size:12px;
      font-weight:700;
      margin-bottom:10px;
    }
    h1{margin:0 0 8px;font-size:28px;letter-spacing:-.03em}
    p{margin:0;color:var(--muted);line-height:1.7;font-size:14px}
    .actions{
      display:grid;
      grid-template-columns:1fr 1fr;
      gap:10px;
      margin-top:14px;
    }
    button,a.btn{
      border:0;
      border-radius:16px;
      padding:12px 14px;
      font-weight:700;
      cursor:pointer;
      text-align:center;
      text-decoration:none;
      font-size:14px;
    }
    button{background:var(--text);color:#fff}
    button.secondary,a.btn{background:#e8ddcf;color:var(--text)}
    .meta{
      display:grid;
      grid-template-columns:1fr;
      gap:10px;
      margin-top:14px;
    }
    .row{
      background:rgba(255,255,255,.7);
      border:1px solid rgba(225,213,196,.95);
      border-radius:18px;
      padding:12px 14px;
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:12px;
      font-size:13px;
    }
    .row strong{font-weight:700}
    .qr{
      margin-top:14px;
      display:grid;
      grid-template-columns:120px 1fr;
      gap:14px;
      align-items:center;
      background:rgba(255,255,255,.74);
      border:1px solid rgba(225,213,196,.95);
      border-radius:22px;
      padding:14px;
    }
    .qr img{
      width:120px;
      height:120px;
      object-fit:contain;
      border-radius:18px;
      background:#fff;
      border:1px solid #eee;
    }
    .qr h2{margin:0 0 6px;font-size:18px}
    .qr p{font-size:13px}
    .viewer{
      margin-top:14px;
      background:rgba(255,255,255,.9);
      border:1px solid rgba(225,213,196,.95);
      border-radius:28px;
      box-shadow:var(--shadow);
      overflow:hidden;
    }
    .viewer-head{
      padding:14px 16px;
      border-bottom:1px solid var(--line);
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:10px;
    }
    .viewer-head h2{
      margin:0;
      font-size:18px;
      letter-spacing:-.02em;
    }
    .viewer-head span{
      font-size:12px;
      color:var(--muted);
      white-space:nowrap;
    }
    .viewer-actions{
      display:flex;
      gap:8px;
      flex-wrap:wrap;
      margin-top:10px;
    }
    .viewer-actions a,
    .viewer-actions button{
      border-radius:999px;
      padding:9px 12px;
      font-size:13px;
      text-decoration:none;
    }
    iframe{
      width:100%;
      height:72vh;
      border:0;
      display:block;
      background:#fff;
    }
    .footer{
      margin-top:12px;
      font-size:12px;
      color:var(--muted);
      text-align:center;
      line-height:1.6;
      padding-bottom:8px;
    }
    @media (max-width: 420px){
      .actions{grid-template-columns:1fr}
      .summary{grid-template-columns:1fr}
      .stack-head{flex-direction:column;align-items:flex-start}
      .qr{grid-template-columns:1fr}
      .qr img{width:100%;height:auto;max-width:180px;justify-self:center}
      iframe{height:66vh}
    }
  </style>
</head>
<body>
  <div class="phone">
    <section class="hero">
      <div class="eyebrow">Fixed Share Link</div>
      <h1>周报分享页</h1>
      <p>客户只需要打开这一页，就能直接看到最新周报，不需要会用 `.md`。</p>

      <div class="actions">
        <button id="reload">刷新内容</button>
        <button id="copyLink" class="secondary">复制链接</button>
        <a class="btn" href="./report-miniapp.html">手机模式</a>
      </div>

      <div class="summary">
        <div class="item">
          <span class="label">给客户看什么</span>
          <span class="value">这是最新周报的固定分享页，不用找 `.md`。</span>
        </div>
        <div class="item">
          <span class="label">怎么打开</span>
          <span class="value">发链接或扫码即可，页面会自动显示最新内容。</span>
        </div>
        <div class="item">
          <span class="label">手机体验</span>
          <span class="value">支持手机直接看，也可点「手机模式」看更清爽版本。</span>
        </div>
      </div>

      <div class="stack">
        <div class="stack-head">
          <h2>客户打开后的阅读顺序</h2>
          <span>无需额外说明</span>
        </div>
        <div class="checklist">
          <div class="check">
            <div class="mark">1</div>
            <div>
              <strong>先看最新结果</strong>
              打开页面后会先看到最新周报内容，不需要知道文件格式。
            </div>
          </div>
          <div class="check">
            <div class="mark">2</div>
            <div>
              <strong>再看关键数据</strong>
              页面里直接呈现周报正文，客户可以在手机上滚动查看。
            </div>
          </div>
          <div class="check">
            <div class="mark">3</div>
            <div>
              <strong>需要时再分享</strong>
              可复制固定链接，或者直接把二维码发给客户。
            </div>
          </div>
        </div>
      </div>

      <div class="meta">
        <div class="row">
          <span>固定链接</span>
          <strong id="shareLink">index.html</strong>
        </div>
        <div class="row">
          <span>最新来源</span>
          <strong id="latestInfo">weekly_report/latest.html</strong>
        </div>
      </div>

      <div class="qr">
        <img src="./share-qr.png" alt="分享链接二维码" />
        <div>
          <h2>扫码打开</h2>
          <p>把这个二维码发给客户即可。客户打开的是固定分享页，页面内容会自动读取最新周报。</p>
        </div>
      </div>
    </section>

    <section class="viewer">
      <div class="viewer-head">
        <h2>最新周报</h2>
        <span id="status">加载中...</span>
      </div>
      <div class="viewer-actions">
        <a id="openLatest" class="btn" href="./weekly_report/latest.html" target="_blank" rel="noopener noreferrer">直接打开最新报告</a>
        <button id="copyReportLink" class="secondary" type="button">复制报告链接</button>
      </div>
      <iframe id="frame" title="周报内容"></iframe>
    </section>

    <div class="footer">
      如果最新周报还没生成，页面会显示提示信息。<br />
      你只需要维护 `weekly_report/latest.html`。
    </div>
  </div>

  <script>
    const frame = document.getElementById('frame');
    const reloadBtn = document.getElementById('reload');
    const copyLinkBtn = document.getElementById('copyLink');
    const copyReportBtn = document.getElementById('copyReportLink');
    const openLatestBtn = document.getElementById('openLatest');
    const status = document.getElementById('status');
    const latestInfo = document.getElementById('latestInfo');
    const shareLink = document.getElementById('shareLink');
    const latestUrl = new URL('./weekly_report/latest.html', location.href);

    function friendlyName(pathname) {
      const name = pathname.split('/').pop() || pathname;
      return name;
    }

    async function loadLatest() {
      status.textContent = '加载中...';
      latestInfo.textContent = friendlyName(latestUrl.pathname);
      shareLink.textContent = friendlyName(location.pathname);
      try {
        const resp = await fetch(latestUrl.toString(), { cache: 'no-store' });
        if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
        const html = await resp.text();
        frame.srcdoc = html;
        status.textContent = '已更新';
      } catch (err) {
        frame.srcdoc = `<html><body style="font-family:system-ui;padding:24px;color:#1f1a17;background:#fffaf2">未找到最新周报：<code>${latestUrl.pathname}</code></body></html>`;
        status.textContent = '未找到最新周报';
      }
    }

    async function copyShareLink() {
      try {
        await navigator.clipboard.writeText(location.href);
        copyLinkBtn.textContent = '已复制';
        setTimeout(() => { copyLinkBtn.textContent = '复制链接'; }, 1500);
      } catch (err) {
        copyLinkBtn.textContent = '复制失败';
        setTimeout(() => { copyLinkBtn.textContent = '复制链接'; }, 1500);
      }
    }

    async function copyReportLink() {
      try {
        await navigator.clipboard.writeText(latestUrl.toString());
        copyReportBtn.textContent = '已复制';
        setTimeout(() => { copyReportBtn.textContent = '复制报告链接'; }, 1500);
      } catch (err) {
        copyReportBtn.textContent = '复制失败';
        setTimeout(() => { copyReportBtn.textContent = '复制报告链接'; }, 1500);
      }
    }

    reloadBtn.addEventListener('click', loadLatest);
    copyLinkBtn.addEventListener('click', copyShareLink);
    copyReportBtn.addEventListener('click', copyReportLink);
    openLatestBtn.addEventListener('click', () => {
      status.textContent = '已打开最新报告';
    });
    loadLatest();
  </script>
</body>
</html>"""


def sync_site() -> None:
    SITE.mkdir(parents=True, exist_ok=True)
    weekly_out = SITE / "weekly_report"
    weekly_out.mkdir(parents=True, exist_ok=True)

    # Copy static assets used by the site.
    subprocess.run(
        ["python3", str(ROOT / "generate_share_qr.py"), "--url", "https://YOUR-USERNAME.github.io/YOUR-REPO/", "--output", str(ROOT / "share-qr.png")],
        check=True,
    )
    shutil.copy2(ROOT / "share-qr.png", SITE / "share-qr.png")
    shutil.copy2(ROOT / "report-miniapp.html", SITE / "report-miniapp.html")
    write_text(SITE / ".nojekyll", "")

    # Build weekly report HTML assets.
    for md_path in sorted(WEEKLY_DIR.glob("*.md")):
        body, toc, _ = render_markdown(read_text(md_path))
        write_text(weekly_out / md_path.with_suffix(".html").name, build_html(md_path.name, body, toc))

    html_reports = sorted(weekly_out.glob("*.html"))
    if html_reports:
      write_text(weekly_out / "latest.html", read_text(html_reports[-1]))

    share_page = build_index()
    write_text(SITE / "index.html", share_page)
    write_text(SITE / "report-share.html", share_page)


def main() -> None:
    sync_site()
    print(SITE)


if __name__ == "__main__":
    main()
