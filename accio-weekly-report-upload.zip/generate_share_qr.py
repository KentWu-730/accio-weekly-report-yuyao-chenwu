#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import qrcode


ROOT = Path(__file__).resolve().parent


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate a QR code for the report share page.")
    parser.add_argument(
        "--url",
        default="https://YOUR-USERNAME.github.io/YOUR-REPO/",
        help="Target URL for the QR code.",
    )
    parser.add_argument(
        "--output",
        default=str(ROOT / "share-qr.png"),
        help="Output PNG path.",
    )
    args = parser.parse_args()

    img = qrcode.make(args.url)
    output = Path(args.output).expanduser().resolve()
    img.save(output)
    print(output)


if __name__ == "__main__":
    main()
