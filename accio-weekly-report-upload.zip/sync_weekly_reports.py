#!/usr/bin/env python3
from __future__ import annotations

import argparse
import time
from pathlib import Path

from md_to_html import build_html, render_markdown


def sync_reports(input_dir: Path, output_dir: Path | None = None) -> list[Path]:
    input_dir = input_dir.expanduser().resolve()
    output_dir = output_dir.expanduser().resolve() if output_dir else input_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    generated: list[Path] = []
    for md_path in sorted(input_dir.glob("*.md")):
        md_text = md_path.read_text(encoding="utf-8")
        body, toc, _ = render_markdown(md_text)
        html = build_html(md_path.name, body, toc)
        html_path = output_dir / md_path.with_suffix(".html").name
        html_path.write_text(html, encoding="utf-8")
        generated.append(html_path)
    if generated:
        latest_source = generated[-1]
        latest_target = output_dir / "latest.html"
        latest_target.write_text(latest_source.read_text(encoding="utf-8"), encoding="utf-8")
        generated.append(latest_target)
    return generated


def watch_reports(input_dir: Path, output_dir: Path | None = None, interval: float = 2.0) -> None:
    input_dir = input_dir.expanduser().resolve()
    output_dir = output_dir.expanduser().resolve() if output_dir else input_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    seen_mtimes: dict[Path, float] = {}
    print(f"watching {input_dir} -> {output_dir} every {interval:.1f}s")

    while True:
        current_files = sorted(input_dir.glob("*.md"))
        changed = False
        for md_path in current_files:
            try:
                mtime = md_path.stat().st_mtime
            except FileNotFoundError:
                continue
            if seen_mtimes.get(md_path) != mtime:
                seen_mtimes[md_path] = mtime
                changed = True

        removed = [path for path in list(seen_mtimes) if path not in current_files]
        if removed:
            for path in removed:
                seen_mtimes.pop(path, None)
                html_path = (output_dir / path.with_suffix(".html").name)
                if html_path.exists():
                    html_path.unlink()
                    print(f"removed {html_path}")
            changed = True

        if changed:
            generated = sync_reports(input_dir, output_dir)
            for path in generated:
                print(path)

        time.sleep(interval)


def main() -> None:
    parser = argparse.ArgumentParser(description="Sync weekly Markdown reports to HTML.")
    parser.add_argument(
        "--input-dir",
        default=str(Path(__file__).resolve().parent / "output" / "weekly_report"),
        help="Directory containing weekly_report_*.md files",
    )
    parser.add_argument(
        "--output-dir",
        default=None,
        help="Optional directory for generated HTML files. Defaults to input dir.",
    )
    parser.add_argument(
        "--watch",
        action="store_true",
        help="Continuously watch the directory and regenerate HTML on changes.",
    )
    parser.add_argument(
        "--interval",
        type=float,
        default=2.0,
        help="Polling interval in seconds for watch mode.",
    )
    args = parser.parse_args()

    input_dir = Path(args.input_dir)
    output_dir = Path(args.output_dir) if args.output_dir else None

    if args.watch:
        watch_reports(input_dir, output_dir, args.interval)
        return

    generated = sync_reports(input_dir, output_dir)
    for path in generated:
        print(path)


if __name__ == "__main__":
    main()
